"""Run: Isaac Sim python.sh test_motion_isaac.py /path/studio_articulated.usdc."""
import sys, json, math, hashlib
from pathlib import Path
asset=Path(sys.argv[1]).resolve();out=asset.parent
from omni.isaac.kit import SimulationApp
app=SimulationApp({'headless':True,'multi_gpu':False},experience=str(out/'physics_only.kit'))
try:
    import omni.usd, carb
    from omni.physx import get_physx_interface
    from pxr import Usd,UsdGeom,UsdPhysics,PhysxSchema,Gf
    assert omni.usd.get_context().open_stage(str(asset))
    stage=omni.usd.get_context().get_stage();stage.SetEditTarget(stage.GetSessionLayer())
    # Physics-only check: avoid allocating renderer memory for the whole office.
    UsdGeom.Imageable(stage.GetPrimAtPath('/World')).MakeInvisible()
    for _ in range(10):app.update()
    rows=json.loads((out/'joints.json').read_text())['joints']
    assert len(rows)==31
    for p in stage.Traverse():
        if p.HasAPI(UsdPhysics.RigidBodyAPI):
            rb=PhysxSchema.PhysxRigidBodyAPI.Apply(p)
            rb.CreateSolverPositionIterationCountAttr(16);rb.CreateSolverVelocityIterationCountAttr(4)
    carb.settings.get_settings().set_bool('/physics/updateToUsd',True)
    physics=PhysxSchema.PhysxSceneAPI.Apply(stage.GetPrimAtPath('/World/PhysicsScene'))
    physics.CreateEnableGPUDynamicsAttr(False);physics.CreateBroadphaseTypeAttr('MBP')
    physics.CreateTimeStepsPerSecondAttr(240)
    physx=get_physx_interface();physx.start_simulation();simulation_time=0.0
    def position(row):
        cache=UsdGeom.XformCache()
        joint=UsdPhysics.Joint(stage.GetPrimAtPath(row['usd_path']))
        m1=cache.GetLocalToWorldTransform(stage.GetPrimAtPath(row['body_path']))
        p0=joint.GetBody0Rel().GetTargets()
        m0=cache.GetLocalToWorldTransform(stage.GetPrimAtPath(p0[0])) if p0 else Gf.Matrix4d(1)
        local=Gf.Matrix4d(1);local.SetRotate(Gf.Quatd(joint.GetLocalRot0Attr().Get()));local.SetTranslateOnly(Gf.Vec3d(joint.GetLocalPos0Attr().Get()))
        relative=m1*(local*m0).GetInverse()
        axis='XYZ'.index(row['axis'])
        if row['type']=='prismatic':return float(relative.ExtractTranslation()[axis])
        q=relative.ExtractRotationQuat();return math.degrees(2*math.atan2(q.GetImaginary()[axis],q.GetReal()))
    def target(row,value):
        drive=UsdPhysics.DriveAPI(stage.GetPrimAtPath(row['usd_path']),'linear' if row['type']=='prismatic' else 'angular')
        drive.GetTargetPositionAttr().Set(value)
    tracks={r['id']:[] for r in rows};samples=[]
    for phase,factor in [('rest',0),('actuate',1),('return',0)]:
        for row in rows:target(row,row['demo']*factor)
        app.update()
        for step in range(720):
            physx.update_simulation(1/240,simulation_time)
            physx.update_transformations(False,True)
            simulation_time+=1/240
            if step%24==0:
                for row in rows:tracks[row['id']].append(position(row))
        values={r['id']:position(r) for r in rows}
        samples.append({'phase':phase,'positions':values})
        print('MOTION_PHASE',phase,json.dumps(values),flush=True)
    results=[]
    for row in rows:
        tolerance=.012 if row['type']=='prismatic' else 3.0
        actuated=samples[1]['positions'][row['id']];returned=samples[2]['positions'][row['id']]
        values=tracks[row['id']]
        passed=all(math.isfinite(v) for v in values) and abs(actuated-row['demo'])<tolerance and abs(returned)<tolerance and min(values)>=row['lower']-tolerance and max(values)<=row['upper']+tolerance
        results.append({'id':row['id'],'target':row['demo'],'actuated':actuated,'returned':returned,'unit':row['unit'],'tolerance':tolerance,'min':min(values),'max':max(values),'passed':passed})
    report={'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'simulator':'Isaac Sim 4.1','physics_dt':1/240,'seconds':9,'joint_count':len(rows),'passed':all(r['passed'] for r in results),'passed_count':sum(r['passed'] for r in results),'tests':results,'limitations':['Estimated geometry, masses, limits and drive gains','Fixed robot base; no walking, balance, navigation or grasp controller','Actuation and return at listed targets, not exhaustive joint-range or collision sweep','Blender and browser are kinematic previews; this report tests USD physics']}
    (out/'motion_report.json').write_text(json.dumps(report,indent=2))
    (out/'motion_trajectories.json').write_text(json.dumps({'sample_dt':.1,'tracks':tracks},indent=2))
    print('MOTION_RESULT',json.dumps(report),flush=True)
    assert report['passed'],'Some joints failed; see motion_report.json'
finally:app.close()
