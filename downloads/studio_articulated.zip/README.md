# Studio Twin — articulated scene

This version adds 31 driven joints: two door hinges, 15 chair swivels, two inferred drawers, and 12 Unitree Go1 leg joints.

## Files and controls

- `studio_articulated.blend`: editable scene, joint pivot objects, motion limits, and a preview animation on frames 1–192. Press Space in Blender to play. This is a kinematic preview, not a Blender rigid-body simulation.
- `studio_articulated.usdc`: full room with rigid bodies, collision geometry, joint limits, position drives, masses, and robot inertias. Keep `textures/` beside it.
- `joints.json`: every joint's USD path, local axis, limits, mass, drive stiffness/damping/force limit, and demonstration target.
- `motion_report.json` and `motion_trajectories.json`: actual Isaac Sim actuation/return measurements for this USD, identified by SHA-256.
- `test_motion_isaac.py` and `physics_only.kit`: repeatable CPU physics check using Isaac Sim 4.1's `python.sh test_motion_isaac.py studio_articulated.usdc`. Keep the Kit configuration beside the USD. No rendered viewport is needed for this check.
- `UNITREE_LICENSE.txt` and `go1.urdf`: official robot source license and joint definition. The URDF is retained as source documentation; its original mesh paths require the official description package if imported separately.

All 31 joints passed a 9-second rest/actuate/return check at 240 Hz. The report records the actual USD SHA-256, measured end positions and sampled limits. The largest angular end-position error was under 0.06 degrees; drawer end-position error was under 0.03 mm at the tested targets.

In Isaac Sim, open the USD, select a joint under `/World/Joints`, and edit **Drive → Target Position** while the timeline plays. Angular USD drive targets use **degrees**; drawer targets use **metres**. `joints.json` contains each allowed range. Zero means the photographed/rest pose, not the manufacturer's joint zero. Go1 entries include `urdf_rest_rad` and the original `urdf_limit_rad` for conversion to robot controllers.

For example, `Motion_North_door` has a demonstration target of -30 degrees; `Motion_Drawer_1` uses -0.18 metres. Restore target position to zero to return to the rest pose.

## Modeling and physics scope

The user confirmed the brand as Unitree. **Go1 is an appearance-based assumption; the exact model has not been confirmed.** Robot meshes, axes, limits, masses, and inertias come from [Unitree's official Go1 description](https://github.com/unitreerobotics/unitree_ros/tree/master/robots/go1_description), under the included BSD 3-Clause license. Fixed-link inertias are combined using the parallel-axis theorem. Visual meshes are simplified; collision shapes use the URDF primitives.

The radar/camera payload and its supports are approximations from the supplied photograph. They are visual attachments; payload inertia and sensor operation are not calibrated. The robot base is fixed for actuation tests. No walking, balance, navigation, grasping, or hardware-control policy is supplied.

The original scene contained no independently modeled drawers. The small two-drawer unit is a functional approximation, not a recovered interior. Furniture masses, limits, friction, and drive gains are estimates. Chair armrests are lowered by 4 cm and the north door leaf raised by 2.5 cm to resolve intersections in the static source; door-panel clearance is also adjusted. Only internal chair-bearing and hinge-jamb collision pairs are filtered; surrounding walls, floors, and furniture retain collision.

The browser and Blender play kinematic previews. Isaac Sim computes physical contact and drive response. Decorative details and thin cables do not have colliders. Door collision meshes use a CPU fallback; GPU particle/deformable contacts have not been validated. The report tests the listed demonstration targets and return to rest; it is not an exhaustive joint-range, contact, or safety certification.

Standalone source photographs are not included. Photo-derived scene textures are retained. The original static Blender/USD files remain separately preserved.
