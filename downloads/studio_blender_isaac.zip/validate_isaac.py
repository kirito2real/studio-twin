import sys,json,hashlib
from pathlib import Path
asset=Path(sys.argv[1]).resolve(); out=asset.parent
try:
    from isaacsim import SimulationApp
except ImportError:
    from omni.isaac.kit import SimulationApp
app=SimulationApp({'headless':True,'width':1280,'height':800,'renderer':'PathTracing','active_gpu':5,'physics_gpu':5,'multi_gpu':False})
try:
    import omni.usd,omni.timeline,carb
    import omni.replicator.core as rep
    from omni.isaac.core import World
    from pxr import Usd,UsdGeom,UsdPhysics,UsdShade,PhysxSchema,Gf
    assert omni.usd.get_context().open_stage(str(asset))
    for _ in range(30): app.update()
    stage=omni.usd.get_context().get_stage(); stage.SetEditTarget(stage.GetSessionLayer())
    assert UsdGeom.GetStageMetersPerUnit(stage)==1 and UsdGeom.GetStageUpAxis(stage)=='Z'
    meshes=[p for p in stage.Traverse() if p.IsA(UsdGeom.Mesh)]
    colliders=[p for p in stage.Traverse() if p.HasAPI(UsdPhysics.CollisionAPI)]
    assert len(colliders)>100
    unresolved=[]
    for p in stage.Traverse():
        if p.IsA(UsdShade.Shader):
            file=UsdShade.Shader(p).GetInput('file')
            if file and file.Get() and not file.Get().resolvedPath: unresolved.append(file.Get().path)
    assert not unresolved,unresolved
    cases=[('floor_entry', (-2.0, -2.65, 1.0), 0.08), ('floor_aisle', (-1.95, 0, 1.0), 0.08), ('floor_rear_aisle', (-2, 2.4, 1), 0.08), ('desk_A2', [-0.20250000059604645, -1.7619999647140503, 1.2], 0.8325), ('desk_A3', [0.92249995470047, -1.9619998931884766, 1.2], 0.8325), ('door_threshold', (-3.9, 3.25, 1.0), 0.08), ('lounge_walkway', (-3.0, 0, 1.0), 0.08), ('recess_floor', (-3.95, -3.95, 1.0), 0.08), ('widened_door_right', (-3.02, 3.25, 1.0), 0.08), ('robot_side_floor', (-2.25, 1.47, 1.0), 0.08)]
    spheres=[]
    for name,position,expected in cases:
        sphere=UsdGeom.Sphere.Define(stage,'/World/PhysicsTest_'+name); sphere.CreateRadiusAttr(.08); sphere.AddTranslateOp().Set(Gf.Vec3d(*position)); sphere.AddOrientOp().Set(Gf.Quatf(1))
        prim=sphere.GetPrim(); UsdPhysics.CollisionAPI.Apply(prim); UsdPhysics.RigidBodyAPI.Apply(prim); UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(.2)
        spheres.append(sphere)
    carb.settings.get_settings().set_bool('/physics/updateToUsd',True)
    world=World(physics_dt=1/240,rendering_dt=1/60,stage_units_in_meters=1); world.reset()
    tracks=[[] for _ in spheres]
    for step in range(1440):
        world.step(render=False)
        for i,s in enumerate(spheres):
            p=s.ComputeLocalToWorldTransform(Usd.TimeCode.Default()).ExtractTranslation(); tracks[i].append([float(v) for v in p])
    results=[]
    for case,track in zip(cases,tracks):
        z=track[-1][2]; stable=max(p[2] for p in track[-240:])-min(p[2] for p in track[-240:])<.005
        results.append({'name':case[0],'start':case[1],'expected_rest_z':case[2],'final':track[-1],'minimum_z':min(p[2] for p in track),'stable_last_second':stable,'pass':abs(z-case[2])<.008 and stable and min(p[2] for p in track)>case[2]-.02})
    report={'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'simulator':'Isaac Sim 4.1','physics_dt':1/240,'steps':1440,'duration_seconds':6,'mesh_count':len(meshes),'static_colliders':len(colliders),'texture_paths_ok':not unresolved,'tests':results,'passed':all(r['pass'] for r in results),'limits':['Static environment only; furniture joints and movable clutter not simulated','No full robot navigation or grasp test','Dimensions estimated, friction and mass not calibrated'],'source_modified':False}
    (out/'physics_report.json').write_text(json.dumps(report,indent=2)); (out/'physics_trajectories.json').write_text(json.dumps(tracks))
    print('PHYSICS_RESULT',json.dumps(report),flush=True)
    world.stop()
    for s in spheres: stage.RemovePrim(s.GetPath())
    cameras={p.GetName():str(p.GetPath()) for p in stage.Traverse() if p.IsA(UsdGeom.Camera)}
    for name in ['Interior','Desk_detail']:
        product=rep.create.render_product(cameras[name],(1280,800)); writer=rep.WriterRegistry.get('BasicWriter'); writer.initialize(output_dir=str(out/'isaac_views'/name),rgb=True); writer.attach([product])
        rep.orchestrator.step(rt_subframes=16,pause_timeline=True); rep.orchestrator.wait_until_complete(); writer.detach(); product.destroy()
        assert list((out/'isaac_views'/name).glob('*.png'))
    assert report['passed'],'Physical support tests failed; see physics_report.json'
finally:
    app.close()
